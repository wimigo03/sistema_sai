<?php

namespace App\Http\Controllers\Almacen\Ingreso;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class IngresoController2 extends Controller
{
    //
}
