<?php

namespace App\Http\Controllers\Activo;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ArchivoVehiculoController extends Controller
{
    //
}
