<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InstruccionvModel extends Model
{
         //
         protected $table = 'instruccionv';

         protected $primaryKey= 'idinstruccionv';

         public $timestamps = false;

         protected $fillable = [
             'nombreinstruccionv'

         ];

         protected $guarded = [


         ];
}
