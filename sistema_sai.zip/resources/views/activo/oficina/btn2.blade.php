
<center>
    <td style="padding: 0;" class="text-center p-1">
        <a class="tts:left tts-slideIn tts-custom" aria-label="Ver Responsables" href="{{ route('activo.responsable.index', )}}">
            <button class="btn btn-sm btn-success font-verdana" type="button"><i class="fa fa-eye" aria-hidden="true"></i>
            </button>
        </a>

     

        <a href="{{route('activo.responsable.create', )}}" class="tts:left tts-slideIn tts-custom" aria-label="Agregar">
            <button class="btn btn-sm btn-primary font-verdana" type="button">
                &nbsp;<i class="fa fa-lg fa-plus" aria-hidden="true"></i>&nbsp;
            </button>
        </a>

  
    </td>
</center>
