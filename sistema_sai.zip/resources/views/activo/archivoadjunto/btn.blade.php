<center>
      <td style="padding: 0;" class="text-center p-1">
        <span class="tts:left tts-slideIn tts-custom" aria-label="Modificar">
            <a href="{{ route('activo.archivoadjunto.edit',$idarchivosadjuntos) }}">
                <span class="text-primary">
                    <i class="fas fa-xl fa-edit"></i>
                </span>
            </a>
        </span>
    </td>
</center>