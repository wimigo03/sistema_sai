<table width="100%">
    <tr style="vertical-align:bottom">
        <td style="width: 33.33%; text-align: center; vertical-align:bottom; font-size:12px;">
            <hr style="width: 100%; border-style: dashed">
            Autorización de asignación
        </td>
        <td style="width: 33.33%; text-align: center; vertical-align:bottom; font-size:12px;">
            <hr style="width: 80%; border-style: dashed">
            Responsable de Activos Fijos
        </td>
        <td style="width: 33.33%; text-align: center; vertical-align:bottom; font-size:12px;">
            <hr style="width: 80%; border-style: dashed">
            Funcionario
        </td>
    </tr>
</table>
