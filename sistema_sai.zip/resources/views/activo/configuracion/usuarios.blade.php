@extends('layouts.app')

@section('content')
    <div class="container">
        <h1 class="mb-4">Administrar Usuarios</h1>

        <a href="{{ route('configuracion.index') }}" class="btn btn-primary mb-4">Volver a Configuración</a>

        <!-- Lógica y formulario para administrar usuarios -->
    </div>
@endsection
